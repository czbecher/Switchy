#ifndef Switchy_h
#define Switchy_h

#include "Arduino.h"
#include <WiFiEsp.h>
#include <WiFiEspUdp.h>
#include <SoftwareSerial.h>
#include <Servo.h>
#include <EEPROM.h>

#define servo_up 0		//servo up position
#define servo_down 90	//servo neutral position
#define servo_neut 40	//servo down position


//returns broadcast IP (192.168.x.255)
IPAddress getBroadIP();

//store SSID & PASS, returns true if both are received
bool srchGPIB_WiFi(char packetBuffer[128], String &ssid, String &pass);

//Parses a message by a delemiter, spits out substring based on index
String parseMessage(String message, char delimeter, int index);

//pings everything on the network every 2 seconds
int beacon(WiFiEspUDP *Udp, int sendagain, uint8_t LEDwifi);

//update DSP, return true if its a query
bool srchGPIB_State(char packetBuffer[128], bool &DSP, bool &onlyquery);

//servo up or down
void servo(Servo &myservo, bool DSP, uint8_t PWMpin, uint8_t LVRpin, uint8_t LEDpin);

//returns battery percentage
int battery(uint8_t BATpin, bool ChrgSts);

//info about packet
void packetinfo(WiFiEspUDP *Udp, int packetSize);

//info about wifi
void printWiFiStatus();

#endif //Switchy_h