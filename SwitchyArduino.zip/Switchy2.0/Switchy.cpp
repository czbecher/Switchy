#include "Switchy.h"

//returns broadcast IP (192.168.x.255)
IPAddress getBroadIP()
{
	IPAddress broadIP = WiFi.localIP();
	broadIP[3] = 255;	
	return broadIP;
}

//store SSID & PASS, return true if both are received
bool srchGPIB_WiFi(char packetBuffer[128], String &ssid, String &pass)
{
	bool gotSSID = false;
	bool gotPASS = false;
	String str[4];	//array of strings
	
	//separate into array of strings
	for(int i=0; i<2; i++)	//expecting 2 strings
	{
		str[i] = parseMessage(String(packetBuffer), ';', i);	//parse by semicolons
	}
	
	//looking for this string: "SYSTem:SSID:<SSID>; SYSTem:PASSword:<password>;"
	int a, b, c;
	for(int i=0; i<2; i++)
	{	
		a = str[i].indexOf("SYST");		//search for SYSTem in packet
		if(a != -1)
		{
			b = str[i].substring(a).indexOf("SSID");	//search for SSID in packet
			if(b != -1)
			{
				c = str[i].substring(a+b).indexOf(":");
				ssid = (str[i].substring(a+b+c+1));
				gotSSID = true;
			}
			
			b = str[i].substring(a).indexOf("PASS");	//search for PASSword in packet
			if(b != -1)
			{
				c = str[i].substring(a+b).indexOf(":");
				pass = str[i].substring(a+b+c+1);
				gotPASS = true;
			} 
		}
	}
	
	return (gotSSID == true && gotPASS == true);	
}

//Parses a message by a delemiter, spits out substring based on index
String parseMessage(String message, char delimeter, int index)
{
	int found = 0;
	int strIndex[] = {0,-1};
	int maxIndex = message.length();
	
	for(int i = 0; i <= maxIndex && found <= index; i++)
	{
		if(message.charAt(i) == delimeter || i == maxIndex)
		{
			found++;
			strIndex[0] = strIndex[1] + 1;
			strIndex[1] = (i == maxIndex) ? i+1 : i;
		}
	}
	return found > index ? message.substring(strIndex[0], strIndex[1]) : "Error";
}

//pings everything on the network every 2 seconds
int beacon(WiFiEspUDP *Udp, int sendagain, uint8_t LEDwifi)
{
	char broadcastBuffer[32];
	
	if(sendagain >= 2000)	//beacon every 2 seconds
	{
		snprintf(broadcastBuffer, 32, "SYSTem:REQuest?");
		Udp->beginPacket("192.168.4.255", 3333);
		Udp->write(broadcastBuffer);
		Udp->endPacket();
		sendagain = 0;
		digitalWrite(LEDwifi, HIGH);
		delay(100);
		digitalWrite(LEDwifi, LOW);
	}
	else
	{
		sendagain += 10;
		delay(10);
	}
	
	return sendagain;
}

//update DSP, return true if its a query
bool srchGPIB_State(char packetBuffer[128], bool &DSP, bool &onlyquery)
{
	onlyquery = 0;
	String pckBuf = String(packetBuffer);
	
	int a = pckBuf.indexOf("STAT");	//search for STATe in packet
	if(a != -1)					
	{								
		//search for ON, OFF or query in packet
		if(pckBuf.substring(a).indexOf("ON") != -1)
			DSP = 1;
			
		else if(pckBuf.substring(a).indexOf("OFF") != -1)
			DSP = 0;
		
		else if(pckBuf.substring(a).indexOf("?") != -1)
			onlyquery = 1;	//only query, skip servo
		
		else
			return false;	//return false if command isn't recognized
	}
	else
		return false;	//return false if command isn't recognized
		
	return true;
}

//servo function
void servo(Servo &myservo, bool DSP, uint8_t PWMpin, uint8_t LVRpin, uint8_t LEDpin)
{
	digitalWrite(LEDpin, DSP);	// update LED
	
	myservo.attach(PWMpin);
	delay(50);					// waits for servo to attach
	Serial.println("doservo");  //for testing
	
	
	if(DSP)
	{
		for(int i=servo_neut; i<=servo_down; i+=2)
		{
			myservo.write(i);
			if(digitalRead(LVRpin))
				i = 1000;
			delay(10);
		}
		Serial.println("servo down");
	}
		
	else
	{
		for(int i=servo_neut; i>=servo_up; i-=2)
		{
			myservo.write(i);
			if(!digitalRead(LVRpin))
				i = -1000;
			delay(10);
		}
		Serial.println("servo up");
	}
	
	myservo.write(servo_neut);	// return to neutral position
	delay(50);					// waits for servo to reach position
	myservo.detach();
}

int battery(uint8_t BATpin, bool ChrgSts)
{	
	int BatPer = 0;
	
	for(int i=0; i<5; i++)	//take average of 5 voltage readings
	{		
		BatPer += 0.2*analogRead(BATpin);
		delay(10);
	}
	
	Serial.print("Battery reading: ");
	Serial.println(BatPer);
	
	if(ChrgSts)		//discharging
		BatPer = map(BatPer, 655, 850, 0, 100);	//convert to % (min 3.2V, max 4.1V)
	else         	//charging            
		BatPer = map(BatPer, 705, 880, 0, 100);	//convert to % (min = 3.4V, max = 4.2V)
		
	if(BatPer > 100)
		BatPer = 100;
	
	return BatPer;
}

void packetinfo(WiFiEspUDP *Udp, int packetSize)
{
	Serial.print("\n\nReceived packet of size ");
	Serial.println(packetSize);
	Serial.print("From ");
	IPAddress remoteIp = Udp->remoteIP();
	Serial.print(remoteIp);
	Serial.print(", port ");
	Serial.println(Udp->remotePort());
}

void printWiFiStatus()
{
	Serial.println("Connected to WiFi");
	Serial.print("SSID: ");
	Serial.println(WiFi.SSID());
	
	IPAddress ip = WiFi.localIP();
	Serial.print("IP Address: ");
	Serial.println(ip);
	
	long rssi = WiFi.RSSI();
	Serial.print("Signal strength (RSSI): ");
	Serial.print(rssi);
	Serial.println(" dBm");
}
