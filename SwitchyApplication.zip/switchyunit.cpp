//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "switchyunit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "switcherframunit"
#pragma resource "*.fmx"
Tswitchyform *switchyform;

//---------------------------------------------------------------------------

__fastcall Tswitchyform::Tswitchyform(TComponent* Owner)
	: TForm(Owner)
{
	switchers = new std::vector<__unsafe Tswitcherframe*>();	//instantiate switchers vector
	fileSetup();		//update from file or create new file
	getMyIP();    		//get local IP and broadcast IP
	tabManager->ActiveTab = tabManager->Tabs[0]; 	//set first tab to visible
    switchyform->OnActivate = FormActivate;
}
//---------------------------------------------------------------------------
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void Tswitchyform::fileSetup()
{
	filepath = System::Ioutils::TPath::GetHomePath() + System::Ioutils::TPath::DirectorySeparatorChar + "Switchy" + System::Ioutils::TPath::DirectorySeparatorChar + "Switchers";		//get filepath
//	helpMemo->Text = filepath;     	//debugging

	switcherinfo.Length = 1000;    	//allows up to 100 switchers
//	TFile::WriteAllLines(filepath, switcherinfo);       //reset file for debugging

	if(System::Sysutils::FileExists(filepath))	//check if file exists
	{
		updatefromfile();                       //open tabs as necessary
	}
	else                                       
	{                                          
		System::Sysutils::CreateDir(System::Ioutils::TPath::GetHomePath() + System::Ioutils::TPath::DirectorySeparatorChar + "Switchy");   //create directory if doesn't exist
		TFile::WriteAllLines(filepath, switcherinfo);       //write 100 blank lines to file to avoid read errors
	}
}
//---------------------------------------------------------------------------

void Tswitchyform::getMyIP()
{
	if(TOSVersion::Platform == TOSVersion::pfWindows)  	//on Windows, use GStack
	{
		TStrings *ips = new TStringList;	//instantiate stringlist

		TIdStack::IncUsage();
		GStack->AddLocalAddressesToList(ips); 	//pass stringlist to GStack to populate with IPs
		TIdStack::DecUsage();

		TStringDynArray IParr = ips->ToStringArray(); 	//convert to array for parsing
		delete ips;

		for(int i=0; i<IParr.Length; i++) 	//search stringlist for valid IP
		{
			if(IParr[i] != "127.0.0.1" && IParr[i] != "192.168.56.1")//don't want localhost or private IP
			{
				myIP = IParr[i];      	//store my IP
				broadIP = myIP.SubString(0, myIP.LastDelimiter('.')) + "255";   //store broadcast IP
				break;         			//assumes the first valid IP is the one used
			}
		}

//		helpMemo->Lines->Insert(0, broadIP);	//debugging
//		helpMemo->Lines->Insert(0, myIP);      //debugging
	}

	if(TOSVersion::Platform == TOSVersion::pfAndroid) 	//on Android, ping myself
	{
		server->Broadcast("IPaddress", server->DefaultPort); 	//broadcast
	}
}
//---------------------------------------------------------------------------

void Tswitchyform::updatefromfile()
{
	switcherinfo = TFile::ReadAllLines(filepath);	//read file into memory

	if(switcherinfo.Length != 1000)                  	//if there aren't 1000 lines, the file has definitely been tampered with
	{
		switcherinfo.Length = 1000;
		TFile::WriteAllLines(filepath, switcherinfo); 	//so erase the file
    }

	for(int i=0; i<100; i++) 	//check file for switchers
	{
		if(switcherinfo[i*10+0] != "")    //if there's a switcher
		{
			againtabitem(switcherinfo[i*10+0].ToInt(), switcherinfo[i*10+1], switcherinfo[i*10+2].ToInt());     //mynumber, myip, mynormalstate
		}
	}
}
//---------------------------------------------------------------------------

void Tswitchyform::writetofile(Tswitcherframe *currswitcher)
{
	int n = currswitcher->getmynumber();
	switcherinfo[n*10+0] = n;            			//add switcher info to array
	switcherinfo[n*10+1] = currswitcher->getmyipaddress();
	switcherinfo[n*10+2] = currswitcher->getmynormalstate();
	switcherinfo[n*10+3] = currswitcher->getschedule();
	switcherinfo[n*10+4] = currswitcher->gethistory();
	TFile::WriteAllLines(filepath, switcherinfo);   //add info to file
}
//---------------------------------------------------------------------------

void Tswitchyform::deletefromfile(String tabname)
{
	for(int i=0; i<tabManager->TabCount-1; i++)
	{
		if(tabManager->Tabs[i]->Text == tabname)
		{
			delete *(switchers->begin()+i);             //delete switcher from vector
			switchers->erase(switchers->begin()+i);   	//delete switcher from vector
			tabManager->Delete(i);						//automatically calls frame destructor

			int n = tabname.Delete0(0,2).ToInt();
			switcherinfo[n*10+0] = "";     	  			//delete switcher info from array
			switcherinfo[n*10+1] = "";
			switcherinfo[n*10+2] = "";
			switcherinfo[n*10+3] = "";
			switcherinfo[n*10+4] = "";
			TFile::WriteAllLines(filepath, switcherinfo);   //delete info from file

            tabcount = tabManager->TabCount;
		}
	}
}
//---------------------------------------------------------------------------

void Tswitchyform::deletealltabs()
{
	for(std::vector<__unsafe Tswitcherframe*>::iterator iter = switchers->begin(); iter != switchers->end(); iter++)
		delete (*iter);                             //delete Tswitcherframe pointers

	while(tabManager->TabCount > 1)
		tabManager->Delete(0);                  	//delete all tabs except settings
	switchers->clear();                             //clear switchers vector

	switcherinfo.Length = 1000;						//reset number of lines just in case
	for(int i=0; i<switcherinfo.Length; i++)
		switcherinfo[i] = "";                   	//clear switcher info

	TFile::WriteAllLines(filepath, switcherinfo);   //delete info from file
    tabcount = 1;
}
//---------------------------------------------------------------------------
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void __fastcall Tswitchyform::cancelBtnClick(TObject *Sender)
{
	delSwitcherVBOX->Visible = false;       //hide popup
	addSwitcherVBOX->Visible = false;       //hide popup
	setupSwitcherVBOX->Visible = false;     //hide popup
	ackLabel->Text = "";
    infoLabel->Text = "";
}
//---------------------------------------------------------------------------

void __fastcall Tswitchyform::delAllBtnClick(TObject *Sender)
{
	deletealltabs();
}
//---------------------------------------------------------------------------

void __fastcall Tswitchyform::OKDelBtnClick(TObject *Sender)
{
	deletefromfile(tabManager->ActiveTab->Text);
	delSwitcherVBOX->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall Tswitchyform::addTabBtnClick(TObject *Sender)
{
	newtabitem();
    addSwitcherVBOX->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall Tswitchyform::sendWiFiInfobtnClick(TObject *Sender)
{
	String sendBuffer = "SYSTem:SSID:" + SSIDedit->Text + "; SYSTem:PASSword:" + PASSedit->Text + ";";
	server->SendBuffer("192.168.4.1", server->DefaultPort, ToBytes(sendBuffer));
}
//---------------------------------------------------------------------------

void __fastcall Tswitchyform::holdGesture(TObject *Sender, const TGestureEventInfo &EventInfo,
          bool &Handled)
{
	if(EventInfo.Location.Y > switchyform->Height-40)		//if a tab was clicked (not just somewhere on the screen)
	{
		delSwitcherVBOX->Visible = true;
		delLabel->Text = "Do you really want to delete " + tabManager->ActiveTab->Text + "?";
    }
}
//---------------------------------------------------------------------------
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void __fastcall Tswitchyform::schedulerTimer(TObject *Sender)
{
	for(std::vector<__unsafe Tswitcherframe*>::iterator iter = switchers->begin(); iter != switchers->end(); iter++)
  		(*iter)->doMyEvents();
}
//---------------------------------------------------------------------------

void __fastcall Tswitchyform::heartbeatTimer(TObject *Sender)
{
	for(std::vector<__unsafe Tswitcherframe*>::iterator iter = switchers->begin(); iter != switchers->end(); iter++)    //iterate through switchers to check times
		if((*iter)->getlastmessage() < (IncSecond(Now(), -20))) 	//if haven't received anything last 20 seconds
			(*iter)->inactive();                                    //grey out tab
}
//---------------------------------------------------------------------------
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void __fastcall Tswitchyform::serverUDPRead(TIdUDPListenerThread *AThread, const TIdBytes AData,
		  TIdSocketHandle *ABinding)
{
	String receiveBuffer = BytesToString(AData);
//	helpMemo->Lines->Insert(0, ABinding->PeerIP);   //debugging

	if(receiveBuffer == "IPaddress") 	//pinged myself
	{
		myIP = ABinding->PeerIP;
		broadIP = myIP.SubString(0, myIP.LastDelimiter('.')) + ".255";	//store broadcast IP
//		helpMemo->Lines->Insert(0, broadIP);      		//debugging
    }

	else if(setupSwitcher(receiveBuffer))  	//check if the switcher has the home wifi info
	{
		setupSwitcherVBOX->Visible = true;	//make popup visible
	}

	else if(unknownSwitcher(receiveBuffer, ABinding->PeerIP)) 	//check if the switcher has a tab
	{
		addSwitcherVBOX->Visible = true;	// make popup visible
	}

	else     								//from existing switcher
	{
		for(std::vector<__unsafe Tswitcherframe*>::iterator iter = switchers->begin(); iter != switchers->end(); iter++)
		{
			if((*iter)->getmyipaddress() == ABinding->PeerIP)
				(*iter)->messageReceived(receiveBuffer);	//pass string to switcher
        }
	}
}
//---------------------------------------------------------------------------
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void __fastcall Tswitchyform::FormActivate(TObject *Sender)
{
	for(std::vector<__unsafe Tswitcherframe*>::iterator iter = switchers->begin(); iter != switchers->end(); iter++)
		(*iter)->setlastmessage();
	delSwitcherVBOX->Visible = false;       //hide popup
//    helpMemo->Lines->Insert(0, "formactivate");
}
//---------------------------------------------------------------------------

void __fastcall Tswitchyform::prevTabUpdate(TObject *Sender)
{
	// Right Gesture - Tab Slide Left unless at the first tab
	if (tabManager->TabIndex > 0 && !delSwitcherVBOX->Visible)
		prevTab->Tab = tabManager->Tabs[tabManager->TabIndex-1];
}
//---------------------------------------------------------------------------

void __fastcall Tswitchyform::nextTabUpdate(TObject *Sender)
{
	//Left Gesture - Tab Slide Right unless at last tab
	if (tabManager->TabIndex < tabManager->TabCount-1 && !delSwitcherVBOX->Visible)
		nextTab->Tab = tabManager->Tabs[tabManager->TabIndex+1];
}
//---------------------------------------------------------------------------
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void Tswitchyform::newtabitem()
{
	TTabItem *currtab = tabManager->Insert(tabManager->TabCount-1);

	switchers->push_back(new Tswitcherframe(currtab, server, tabcount, ASPSwitch->IsChecked, newswitcherIP));	//instantiate the switcher (frame) object
	writetofile(switchers->back());            	//write switcher info to file
														
	currtab->Touch->InteractiveGestures.Contains(TInteractiveGesture::LongTap);
	currtab->OnGesture = holdGesture;
	currtab->AddObject(switchers->back());    	//add frame to new tab
	currtab->Text = "SW" + IntToStr(tabcount);  //new tab text
	tabManager->ActiveTab = currtab;  			//switch to new tab
	tabcount++;                          		//increment tabcount
}
//---------------------------------------------------------------------------

void Tswitchyform::againtabitem(int tabnum, String IP, bool normalstate)
{
	TTabItem *currtab = tabManager->Insert(tabManager->TabCount-1);
	switchers->push_back(new Tswitcherframe(currtab, server, tabnum, normalstate, IP));		//instantiate the switcher (frame) object
                                                  
	currtab->Touch->InteractiveGestures.Contains(TInteractiveGesture::LongTap);
	currtab->OnGesture = holdGesture;
	currtab->AddObject(switchers->back());    	//add frame to new tab
	currtab->Text = "SW" + IntToStr(tabnum); 	//new tab text
	tabcount = tabnum + 1;                    	//set tabcount
}
//---------------------------------------------------------------------------

bool Tswitchyform::setupSwitcher(String receiveBuffer)          //returns true if switcher needs to be set up
{
	bool retVal = false;

    //Pos returns differently on windows vs android
	if(TOSVersion::Platform == TOSVersion::pfWindows) 			//for windows
	{
		int a = receiveBuffer.Pos("SYST");          //search for SYSTem in packet
		if(a)
		{
			int b = receiveBuffer.SubString(a, 15).Pos("REQ");  //search for REQ in packet
			if(b)
			{
				retVal = true;                      //switcher needs to be set up
				if(receiveBuffer.SubString(a+b, 15).Pos("?"))   //search for ? in packet
				{
					cancelSetupBtn->Text = "Cancel";
				}

				if(receiveBuffer.SubString(a+b, 15).Pos("ACK")) //search for ACKnowledged in packet
				{
					ackLabel->Text = "The WiFi SSID and Password have been received.  The switcher will now switch to your home WiFi.  Please go into your phone's WiFi settings and switch back to your home WiFi, then restart the application.";
					infoLabel->Text = "If the Switcher is unable to connect to your home WiFi, it will automatically reenter Setup mode.  If this happens, please connect to the Switcher's WiFi network and reenter your SSID and Password.";
					cancelSetupBtn->Text = "OK";
				}
            }
		}
	}

	if(TOSVersion::Platform == TOSVersion::pfAndroid) 			//for android
	{
		int a = receiveBuffer.Pos("SYST");          			//search for SYSTem in packet
		if(a >= 0)
		{
			int b = receiveBuffer.SubString(a, 15).Pos("REQ");	//search for REQ in packet
			if(b >= 0)
			{
				retVal = true;
				if(receiveBuffer.SubString(a+b, 15).Pos("?") >= 0)	//search for ? in packet
				{
					cancelSetupBtn->Text = "Cancel";
				}

                if(receiveBuffer.SubString(a+b, 15).Pos("ACK") >= 0) //search for ACKnowledged in packet
				{
					ackLabel->Text = "The WiFi SSID and Password have been received.  The switcher will now switch to your home WiFi.  Please go into your phone's WiFi settings and switch back to your home WiFi.";
					infoLabel->Text = "If the Switcher is unable to connect to your home WiFi, it will automatically reenter Setup mode.  If this happens, please connect to the Switcher's WiFi network and reenter your SSID and Password.";
					cancelSetupBtn->Text = "OK";
				}
            }
		}
	}

	return retVal;
}
//---------------------------------------------------------------------------

bool Tswitchyform::unknownSwitcher(String receiveBuffer, String IP) 	//check if if we recognize the IP
{
	if(TOSVersion::Platform == TOSVersion::pfWindows) 		//for windows
		if(receiveBuffer.Pos("?")){return false;}     		//return false if it contains a query (pinged myself)

	if(TOSVersion::Platform == TOSVersion::pfAndroid) 		//for android
		if(receiveBuffer.Pos("?") >= 0){return false;}     	//return false if it contains a query (pinged myself)

	for(std::vector<__unsafe Tswitcherframe*>::iterator iter = switchers->begin(); iter != switchers->end(); iter++)    //iterate through switchers to look for addresses
		if((*iter)->getmyipaddress() == IP){return false;}	//return false if IP is recognized
						
	newswitcherIP = IP;     //store IP so it can be used later reference 

	return true;        	//return true if IP isn't recognized and isn't a query
}
//---------------------------------------------------------------------------
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void __fastcall Tswitchyform::helpMemoClick(TObject *Sender)
{
	helpMemo->Lines->Clear();  //clears memo when clicked
}
//---------------------------------------------------------------------------

void __fastcall Tswitchyform::helpSetupClick(TObject *Sender)
{
	helpMemo->Text = "To connect to a new Switcher which has never been "
	"connected to your WiFi network, first turn the Switcher on.  Within 1 "
	"minute the Switcher will enter into setup mode.  The green WiFi LED at the "
	"bottom of the board will flash every second.  Enter into your device's "
	"WiFi settings and connect to \"Switcher Setup\", then close and reopen "
	"this application.  A popup window will appear which will guide you through "
	"the next steps."
	"\n\n"
    "The password for \"Switcher Setup\" is \"setupmyswitcher\"."
	"\n\n"
	"If the Switcher is already connected to your WiFi network, and this device "
	"is connected to the same network, a popup will appear within ten seconds "
	"to add the Switcher.  If the popup does not appear, please restart the "
	"application.";
}
//---------------------------------------------------------------------------


void __fastcall Tswitchyform::helpRegularClick(TObject *Sender)
{
	helpMemo->Text = "Each tab in this application controls 1 Switcher."
	"\n\n"
	"To delete a Switcher, press and hold the tab at the bottom of the application."
	"\n\n"
	"The ON/OFF button toggles the Switcher.  It also indicates the current state "
	"of the Switcher."
	"\n\n"
	"The Scheduler button toggles the Switcher at a certain time, like an alarm."
	"\n\n"
	"The Timer button toggles the Switcher after a certain period of time.";
}
//---------------------------------------------------------------------------


