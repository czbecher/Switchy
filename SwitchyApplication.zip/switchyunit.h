//---------------------------------------------------------------------------

#ifndef switchyunitH
#define switchyunitH
//---------------------------------------------------------------------------

#include <System.Classes.hpp>
#include <System.Ioutils.hpp>
#include <System.DateUtils.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.Edit.hpp>
#include <FMX.EditBox.hpp>
#include <FMX.Layouts.hpp>
#include <FMX.Memo.hpp>
#include <FMX.Objects.hpp>
#include <FMX.ScrollBox.hpp>
#include <FMX.SpinBox.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.TabControl.hpp>
#include <FMX.Types.hpp>
#include <IdBaseComponent.hpp>
#include <IdComponent.hpp>
#include <IdGlobal.hpp>
#include <IdSocketHandle.hpp>
#include <IdUDPBase.hpp>
#include <IdUDPServer.hpp>
#include <System.Devices.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <FMX.TabControl.hpp>
#include <FMX.Types.hpp>
#include "switcherframunit.h"
#include <FMX.Controls.Presentation.hpp>
#include <FMX.StdCtrls.hpp>
#include <IdBaseComponent.hpp>
#include <IdComponent.hpp>
#include <IdUDPBase.hpp>
#include <IdUDPServer.hpp>
#include <IdGlobal.hpp>
#include <IdSocketHandle.hpp>
#include <FMX.Colors.hpp>
#include <FMX.Layouts.hpp>
#include <FMX.ListBox.hpp>
#include <FMX.Objects.hpp>
#include <FMX.Edit.hpp>
#include <FMX.EditBox.hpp>
#include <FMX.SpinBox.hpp>
#include <Data.DB.hpp>
#include <Datasnap.DBClient.hpp>
#include <FMX.NumberBox.hpp>
#include <FMX.Memo.hpp>
#include <FMX.ScrollBox.hpp>
#include <IdSystatUDP.hpp>
#include <IdUDPClient.hpp>
#include <IdIPWatch.hpp>
#include <FMX.Gestures.hpp>
#include <FMX.ActnList.hpp>
#include <System.Actions.hpp>
#include <vector>

//---------------------------------------------------------------------------
class Tswitchyform : public TForm
{
__published:	// IDE-managed Components
	TStyleBook *StyleBook1;     //stylebook
	TIdUDPServer *server;       //UDP server
	TTabControl *tabManager;    //tab manager
	TTabItem *settings;         //settings tab

	//timers
	TTimer *scheduler;
	TTimer *heartbeat;

	//buttons
	TButton *delAllBtn;
	TMemo *helpMemo;
	TButton *helpSetup;
	TButton *helpRegular;
	TActionList *ActionList;
	TChangeTabAction *nextTab;
	TChangeTabAction *prevTab;
	TGestureManager *GestureManager1;
	TLayout *delSwitcherVBOX;
	TRectangle *delBack;
	TLabel *delLabel;
	TLayout *delHBOX;
	TButton *cancelDelBtn;
	TButton *OKDelBtn;
	TLayout *addSwitcherVBOX;
	TRectangle *addBack;
	TButton *addTabBtn;
	TLabel *addTitleLabel;
	TButton *cancelAddBtn;
	TLabel *ASPLabel;
	TSwitch *ASPSwitch;
	TLabel *addInstructLabel;
	TLayout *setupSwitcherVBOX;
	TRectangle *setupBack;
	TLabel *instructlabel;
	TEdit *SSIDedit;
	TEdit *PASSedit;
	TButton *sendWiFiInfobtn;
	TLabel *ackLabel;
	TButton *cancelSetupBtn;
	TLabel *infoLabel;        //debugging
	void __fastcall delAllBtnClick(TObject *Sender);
	void __fastcall cancelBtnClick(TObject *Sender);
	void __fastcall OKDelBtnClick(TObject *Sender);
	void __fastcall addTabBtnClick(TObject *Sender);
	void __fastcall sendWiFiInfobtnClick(TObject *Sender);
	void __fastcall holdGesture(TObject *Sender, const TGestureEventInfo &EventInfo, bool &Handled);

	//timers
	void __fastcall schedulerTimer(TObject *Sender);
	void __fastcall heartbeatTimer(TObject *Sender);

    //server
	void __fastcall serverUDPRead(TIdUDPListenerThread *AThread, const TIdBytes AData,
		  TIdSocketHandle *ABinding);

	//form management
	void __fastcall FormActivate(TObject *Sender);  //reset time of last message
	void __fastcall prevTabUpdate(TObject *Sender); //swipe for previous tab
	void __fastcall nextTabUpdate(TObject *Sender); //swipe for next tab

    //user help
	void __fastcall helpMemoClick(TObject *Sender);
	void __fastcall helpSetupClick(TObject *Sender);
	void __fastcall helpRegularClick(TObject *Sender);


public:		// User declarations
	__fastcall Tswitchyform(TComponent* Owner);     //constructor


private:	// User declarations
	std::vector<__unsafe Tswitcherframe*> *switchers;     //vector of switchers, unsafe for Android

	int tabcount = 1;                   //the number of tabs, also corresponds to switcher array address
	String newswitcherIP;               //temporary storage of IP for new switcher
	String filepath;                    //file where switcher info is stored
	TStringDynArray switcherinfo;       //variable to hold switcher info
	String myIP;                        //local IP address, not localhost or private IP
	String broadIP;                     //IP to broadcast to all switchers

	void fileSetup();    								//creates new file or updates from existing file
	void getMyIP();                 					//sets the device's IP address
	void updatefromfile();                              //adds all switchers on file
	void writetofile(Tswitcherframe *currswitcher);   	//writes ip address, schedules, and history to a file for that switcher
	void deletefromfile(String tabname);  				//erases file for that switcher
	void deletealltabs();                               //delete all switchers, erases all switchers on file

	void newtabitem();                  								//creates a new tab in the second last postion, calls frame constructor
	void againtabitem(int tabcount, String IP, bool normalstate);       //recreates the tab in the second last postion, calls frame constructor
	bool setupSwitcher(String receiveBuffer); 							//returns true if its a request to set up a new switcher
	bool unknownSwitcher(String receiveBuffer, String IP);  			//returns true if its a switcher without a tab

};
//---------------------------------------------------------------------------
extern PACKAGE Tswitchyform *switchyform;
//---------------------------------------------------------------------------

#endif
