//---------------------------------------------------------------------------

#ifndef switcherframunitH
#define switcherframunitH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <System.DateUtils.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Colors.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.Types.hpp>
#include <FMX.Objects.hpp>
#include <FMX.Layouts.hpp>
#include <FMX.ListBox.hpp>
#include <IdBaseComponent.hpp>
#include <IdComponent.hpp>
#include <IdUDPBase.hpp>
#include <IdUDPServer.hpp>
#include <FMX.DateTimeCtrls.hpp>
#include <FMX.Edit.hpp>
#include <FMX.EditBox.hpp>
#include <FMX.NumberBox.hpp>
#include <vector>
//---------------------------------------------------------------------------

class Scheduler
{
public:
	bool active;    	//inactive by default, constructor sets HIGH
	TTime time;    		//time to switch
	bool DSP;       	//on or off

    Scheduler();    //used at formCreate() to initialize switcher array
	Scheduler(TTime ntime, bool nDSP);    //overloaded constructor
};

//---------------------------------------------------------------------------

class Tswitcherframe : public TFrame
{
__published:	// IDE-managed Components

	TTimer *timer;	//timer

	//ON OFF button
	TColorButton *button;
	TLabel *buttonLabel;
	
	//battery bar
	TLayout *batHBOX;
	TProgressBar *batBar;
	TLabel *batPer;
	TListBox *schList;
	
	//historyList
	TRectangle *histLabelBack;
	TListBox *histList;
	TLayout *schtimHBOX;
	TButton *schSchBtn;
	TButton *schTimBtn;
	TRectangle *eventsLabelBack;
	TLabel *eventsLabel;
	TLayout *timerVBOX;
	TRectangle *timerBack;
	TLayout *timerHBOX3;
	TButton *timerCancel;
	TButton *timerOK;
	TLayout *timerHBOX1;
	TLabel *timerHrLabel;
	TLabel *timerMinLabel;
	TLabel *timerSecLabel;
	TLayout *timerHBOX2;
	TNumberBox *timerHrEdit;
	TNumberBox *timerSecEdit;
	TNumberBox *timerMinEdit;
	TSwitch *timerSwitch;
	TLayout *schedulerVBOX;
	TRectangle *schedulerBack;
	TLayout *schedulerHBOX2;
	TButton *schedulerCancel;
	TButton *schedulerOK;
	TLayout *schedulerHBOX1;
	TTimeEdit *schedulerTimeEdit;
	TSwitch *schedulerSwitch;
	TLabel *schedulerLabel;
	TRectangle *greyVBOX;
	TRectangle *greyBack;
	TLabel *greyLabel;
	TButton *reconnectBtn;
	TLabel *reconLabel;
	
	void __fastcall buttonClick(TObject *Sender);
	void __fastcall batPerClick(TObject *Sender);
	void __fastcall schSchBtnClick(TObject *Sender);
	void __fastcall schTimBtnClick(TObject *Sender);
	void __fastcall timerOKClick(TObject *Sender);
	void __fastcall schedulerOKClick(TObject *Sender);
	void __fastcall CancelClick(TObject *Sender);

	void __fastcall schedulerSwitchSwitch(TObject *Sender);
	void __fastcall timerTimer(TObject *Sender);
	void __fastcall reconnectBtnClick(TObject *Sender);

private:	// User declarations
	bool pressed;                         	//previously on/off
	int timersecs;                          //number of seconds for the timer
    int reconattempts;                 //number of reconnect attempts
	TIdUDPServer *server;                 	//instantiated in switchyunit.cpp
	std::vector<Scheduler> *myevents;     	//vector of scheduler events

	int mynumber;           //number
	String myipaddress;     //ipaddress of switcher
	String schedule;        //comma delimited string of schedules
	String history;         //comma delimted string of history events
	bool mynormalstate;   	//normal state of light switch
	bool ASP;				//numbers from receiveBuffer
	int percentage;     	//battery percentage
	bool ChrgSts;           //charging status
	TTime lastmessage;      //time the most recent message was received

public:		// User declarations
	__fastcall Tswitcherframe(TComponent* Owner, TIdUDPServer* UDPserver, int number, int normalstate, String ipaddress);
	__fastcall Tswitcherframe(TComponent* Owner, TIdUDPServer* UDPserver, int number, int normalstate, String ipaddress, String schedge, String hist);  	//might just delete this
	__fastcall ~Tswitcherframe();

	void stateMessage(bool DSP);						//sends switch command to switcher
	void queryMessage();        						//sends query command to switcher
	void messageReceived(String message);               //received message from switcher
	void srchGPIB(DynamicArray<String> receiveBuffer);	//searches for GPIB commands and updates ASP, BatPer, ChrgSts
	void doMyEvents();
	void inactive();

	//mutators
	void setmynumber(int number){mynumber = number;}
	void setmyipaddress(String ipaddress){myipaddress = ipaddress;}
	void setmynormalstate(bool normalstate){mynormalstate = normalstate;}
	void setschedule(String schedge){schedule = schedge;}      //eventually needs to change the TListBox
	void sethistory(String hist){schedule = hist;}         	//eventually needs to change the TListBox
    void setlastmessage(){lastmessage = Now();}

	//accessors
	int getmynumber(){return mynumber;}
	bool getmynormalstate(){return mynormalstate;}
	String getmyipaddress(){return myipaddress;}
	String getschedule(){return schedule;}
	String gethistory(){return history;}
	TTime getlastmessage(){return lastmessage;}
};
//---------------------------------------------------------------------------
extern PACKAGE Tswitcherframe *switcherframe;
//---------------------------------------------------------------------------
#endif
