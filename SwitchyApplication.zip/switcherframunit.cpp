//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "switcherframunit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
Tswitcherframe *switcherframe;
//---------------------------------------------------------------------------

Scheduler::Scheduler()  //default constructor
{
	active = false;		//unused by default
	time = NULL;
	DSP = false;
}
//---------------------------------------------------------------------------

Scheduler::Scheduler(TTime ntime, bool nDSP)  //overloaded constructor
{
	active = true;		//sets to active so it can be used
	time = ntime;      	//event time
	DSP = nDSP;      	//event switch position
}
//---------------------------------------------------------------------------

__fastcall Tswitcherframe::Tswitcherframe(TComponent* Owner, TIdUDPServer* UDPserver, int number, int normalstate, String ipaddress)
	: TFrame(Owner)
{
	setmynumber(number);
	server = UDPserver;
	setmyipaddress(ipaddress);
	setmynormalstate(normalstate);
	setlastmessage();

	histList->Items->Add("");  		//initialize list
	queryMessage();                 //get current info

	myevents = new std::vector<Scheduler>();    //instantiate events list
}
//---------------------------------------------------------------------------

Tswitcherframe::~Tswitcherframe()
{
	delete myevents;
}
//---------------------------------------------------------------------------

void __fastcall Tswitcherframe::buttonClick(TObject *Sender)
{
	stateMessage(pressed);  	//send ON/OFF message
	button->Color = 0;      	//make button black while waiting for response
}
//---------------------------------------------------------------------------

void __fastcall Tswitcherframe::batPerClick(TObject *Sender)
{
    queryMessage();
}
//---------------------------------------------------------------------------

void __fastcall Tswitcherframe::schSchBtnClick(TObject *Sender)
{
	timerVBOX->Visible = false;
	schedulerVBOX->Visible = !schedulerVBOX->Visible;
	schedulerTimeEdit->Time = Now();        //update timeedit to current time
	schedulerSwitchSwitch(this);
}
//---------------------------------------------------------------------------

void __fastcall Tswitcherframe::schTimBtnClick(TObject *Sender)
{
	schedulerVBOX->Visible = false;
	timerVBOX->Visible = !timerVBOX->Visible;
}
//---------------------------------------------------------------------------

void __fastcall Tswitcherframe::timerOKClick(TObject *Sender)
{
	timersecs = (timerSecEdit->Value + 60*(timerMinEdit->Value + 60*(timerHrEdit->Value)));	//get values from numberboxes
	schList->Items->Insert(0, "T-" + String(timersecs) + " seconds");     				   	//add to schedulerList

	timer->Enabled = true;	//enable timer
	CancelClick(this);     	//close popup
}
//---------------------------------------------------------------------------

void __fastcall Tswitcherframe::schedulerOKClick(TObject *Sender)
{
	schList->Items->Insert(0, schedulerLabel->Text);     //add to schedulerList

	Word hr, min, sec, msec;                                     //temp variables
	DecodeTime(schedulerTimeEdit->Time, hr, min, sec, msec);    //remove seconds and milliseconds
	myevents->push_back(Scheduler(EncodeTime(hr, min, 0, 0), schedulerSwitch->IsChecked));	//save event
	CancelClick(this);     	//close popup
}
//---------------------------------------------------------------------------

void __fastcall Tswitcherframe::CancelClick(TObject *Sender)
{
	schedulerVBOX->Visible = false;
	timerVBOX->Visible = false;
}
//---------------------------------------------------------------------------
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void __fastcall Tswitcherframe::schedulerSwitchSwitch(TObject *Sender)
{
    //update label to current settings
	String state = schedulerSwitch->IsChecked ? "ON" : "OFF";
	schedulerLabel->Text = "Switch to " + state + " at " + schedulerTimeEdit->Time.FormatString("h:mm AM/PM");

}
//---------------------------------------------------------------------------

void __fastcall Tswitcherframe::timerTimer(TObject *Sender)
{
	int index = schList->Items->IndexOf("T-" + String(timersecs) + " seconds");     //find timer item

    timersecs -= 1;
	schList->ItemByIndex(index)->Text = "T-" + String(timersecs) + " seconds";      //update label
//	histList->Items->Insert(0, String(timersecs));  //debugging

	if(timersecs <= 0)
	{
		stateMessage(timerSwitch->IsChecked);   //send the message
		timer->Enabled = false;     			//timer has occured, disable it
        schList->Items->Delete(index);          //delete from list
	}
}
//---------------------------------------------------------------------------

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void Tswitcherframe::stateMessage(bool DSP)
{
	String sendBuffer;

	if(DSP)
		sendBuffer = mynormalstate ? "STATe ON" : "STATe OFF";  //ON if normalstate is HIGH, OFF if LOW
	else
		sendBuffer = !mynormalstate ? "STATe ON" : "STATe OFF"; //vice versa

	server->SendBuffer(myipaddress, server->DefaultPort, ToBytes(sendBuffer));
//	schList->Items->Insert(0, sendBuffer);      //debugging
}
//---------------------------------------------------------------------------

void Tswitcherframe::queryMessage()
{
	server->SendBuffer(myipaddress, server->DefaultPort, ToBytes("STATe?"));
//	schList->Items->Insert(0, "STATe?");      	//debugging
}
//---------------------------------------------------------------------------

void Tswitcherframe::messageReceived(String message)
{
	TStringDynArray receiveBuffer = SplitString(message, ';');  //parse by commas
//	histList->Items->Insert(0, message);    //debugging
	srchGPIB(receiveBuffer);       	//searches for GPIB commands and updates global variables

	greyVBOX->Visible = false;  	//un-grey out
    reconattempts = 0;				//reset reconnect attempts
	String printBuffer;         	//message for history list
	if(ASP == mynormalstate)
	{
		button->Color = 0xFF008000;     //changes button color to green
		pressed = 0;                	//update pressed variable
		printBuffer = "ON  at ";
	}
	else if (ASP == !mynormalstate)
	{
		button->Color = 0xFF808080;   	//changes button color to grey
		pressed = 1;                    //update pressed variable
		printBuffer = "OFF at ";
	}

    lastmessage = Now();

	String temp = histList->ItemByIndex(0)->Text;       //only prints if different
	if(printBuffer.SubString(0,2) != temp.SubString(0,2))
		histList->Items->Insert(0, printBuffer + lastmessage.TimeString());

	batPer->TextSettings->FontColor = ChrgSts ? 0xFF008000 : 0xFFFF0000;

	if(ChrgSts == 0 && percentage < batBar->Value)		//only update if discharging and percentage decreases
	{
		batPer->Text = String(percentage) + "%";
		batBar->Value = percentage;
	}
	else if(ChrgSts == 1 && percentage > batBar->Value)	//or if charging and percentage increases
	{
		batPer->Text = String(percentage) + "%";
		batBar->Value = percentage;
	}
	else if(batBar->Value == 0)						  	//or if first time
	{
		batPer->Text = String(percentage) + "%";
		batBar->Value = percentage;
	}
}
//---------------------------------------------------------------------------

void Tswitcherframe::srchGPIB(DynamicArray<String> receiveBuffer)
{
	if(TOSVersion::Platform == TOSVersion::pfWindows) 			//for windows
	{
		for(uint8_t i = 0; i<3; i++)
		{
			if(int a = receiveBuffer[i].Pos("STAT"))			//search for STATe in packet
			{
				if(receiveBuffer[i].SubString(a, 15).Pos("1"))	//search for 1 or 0 in substring
					ASP = 1;                                    //set global variable

				else if(receiveBuffer[i].SubString(a, 15).Pos("0"))
					ASP = 0;
			}

			else if(int a = receiveBuffer[i].Pos("BATT"))		//search for BATTery in packet
			{
				if(int b = receiveBuffer[i].SubString(a, 15).Pos("VOLT"))   	//search for VOLTage
				{
					int c = receiveBuffer[i].SubString(a+b, 15).Pos(" ");       //retrieve voltage
					percentage = receiveBuffer[i].SubString(a+b+c, 15).ToInt();
				}

				else if(int b = receiveBuffer[i].SubString(a, 15).Pos("DISC"))  //search for DISCharge
				{
					if(receiveBuffer[i].SubString(a+b, 15).Pos("1"))     		//search for 1 or 0 in substring
						ChrgSts = 0;                                            //set global variable (1 = 0)

					else if(receiveBuffer[i].SubString(a+b, 15).Pos("0"))
						ChrgSts = 1;
				}
			}
		}
	}

	else if(TOSVersion::Platform == TOSVersion::pfAndroid) 		//if android
	{
        for(uint8_t i = 0; i<3; i++)
		{
			int a;

			a = receiveBuffer[i].Pos("STAT");     	//search for STATe in packet
			if(a >= 0)
			{
				if(receiveBuffer[i].SubString(a, 15).Pos("1") >= 0)		//search for 1 or 0 in substring
					ASP = 1;                                    		//set global variable

				else if(receiveBuffer[i].SubString(a, 15).Pos("0") >= 0)
					ASP = 0;
			}

			a = receiveBuffer[i].Pos("BATT");     	//search for BATTery in packet
			if(a >= 0)
			{
				int b;

				b = receiveBuffer[i].SubString(a, 15).Pos("VOLT");		//search for VOLTage in substring
                if(b >= 0)
				{
					int c = receiveBuffer[i].SubString(a+b, 15).Pos(" ");          	//retrieve voltage
					percentage = receiveBuffer[i].SubString(a+b+c, 15).ToInt();
				}

				b = receiveBuffer[i].SubString(a, 15).Pos("DISC");		//search for DISCharge in substring
				if(b >= 0)
				{
					if(receiveBuffer[i].SubString(a+b, 15).Pos("1") >= 0)     		//search for 1 or 0 in substring
						ChrgSts = 0;                                     			//set global variable (1 = 0)

					else if(receiveBuffer[i].SubString(a+b, 15).Pos("0") >= 0)
						ChrgSts = 1;                                     			//set global variable (1 = 0)
				}
			}
		}
	}
}
//---------------------------------------------------------------------------

void Tswitcherframe::doMyEvents()
{
	for(std::vector<Scheduler>::iterator iter = myevents->begin(); iter != myevents->end(); iter++)     //iterate through scheduler to find events
	{
		if(iter->active && iter->time <= Time())	//must be active & time have passed
		{
			stateMessage(iter->DSP);  	//pass message to switcher
			iter->active = 0;   		//deactivate once it has occured
		}
	}
}
//---------------------------------------------------------------------------

void Tswitcherframe::inactive()
{
	if(!greyVBOX->Visible)
	{
		greyVBOX->Visible = true;
		reconattempts = 0;				//reset reconnect attempts
        reconLabel->Text = "Reconnect attempts: 0";
    }
}
//---------------------------------------------------------------------------

void __fastcall Tswitcherframe::reconnectBtnClick(TObject *Sender)
{
	queryMessage();
    reconattempts += 1;
	reconLabel->Text = "Reconnect attempts: " + String(reconattempts);
}
//---------------------------------------------------------------------------


